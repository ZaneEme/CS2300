from Game import Game

if __name__ == "__main__" : 
    newGame = Game()
    newGame.run()
